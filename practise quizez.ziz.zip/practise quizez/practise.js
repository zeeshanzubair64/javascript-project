window.onload = function() {
    shan(0);
}


const questions = [
    {
    id:1,
    question : " Q1 = what is your name ?",
    answer :  'muhammad zeeshn',
    options : [
        'muhammad zeeshan',
        'muhammad noman',
        'muhammad kamran',
        'muhammad talha',

    ]
},
{
    id:2,
    question : ' Q2 = what is your university name ?',
    answer :  'virtual university',
    options : [
        'virtual university',
        'iqra university',
        ' karachi university',
        'allama iqbal university',

    ]
},
{
    id:3,
    question : ' Q3 = in which class you are ?',
    answer :12,
    options : [
        12,
     13,
     14, 
     15,
    ]
}

]
function foamsubmit(e){
    e.preventDefault();
 let name = document.forms["name-1"]["name-2"].value;
  let set123   = sessionStorage.setItem = ("name",name);
 

 location.href = "index.html";
}

let question_count = 0;
function next(){
    question_count++;
    shan(question_count);
    let user_answer = document.querySelector('li.active');
    if (user_answer===questions[count].answer){
        points = 10 + points;
        console.log(points);
    }
    question_count++;
    shan(question_count);
}

function shan(count) {
    let zeeshan = document.querySelector("#zeeshan");
    // zeeshan.innerHTML = "<h2>" + questions[count].question + "</h2>";
    zeeshan.innerHTML =
     `<h2>${questions[count].question}</h2>  
    <ul>
    <li class="option" id="option1">${questions[count].options[0]}</li>
     <li class="option" id="option2">${questions[count].options[1]}</li>
    <li class="option" id="option3">${questions[count].options[2]}</li>
   <li class="option" id="option4">${questions[count].options[3]}</li>
</ul>`           
nomanclass();
}

function nomanclass() {
    let option = document.querySelectorAll("li.option");
    for(i=0; i<option.length; i++){
        option[i].onclick = function(){
            for(j=0; j<option.length; j++){
                if(option[j].classList.contains("active-33")){
                    option.classList.remove("active-33");
                }
            }
            option.classList.add("active-33");
        }
    }

}

let username = sessionStorage.getItem(set123);

let userid = document.getElementById("namesuser").innerHTML = "username";
console.log(userid);
