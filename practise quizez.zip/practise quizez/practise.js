window.onload = function () {
    show(count);
    display(count_);
    display_2(count_2);
}

let geography = [
    {
        'Question': 'Q1 = Which of the following statements is incorrect about the Planet Mars',
        'answer': 'after the moon it is the brightest object in our night sky',
        Options: [
            ' It has two permanent polar ice caps',
            ' After the Moon, it is the brightest object in our night sky',
            ' Liquid water cannot exist on the surface of Mars due to low atmospheric pressure',
            ' Mars is less dense than Earth'
        ]

    },
    {
        'Question': 'Q2 = Who is known as father of geography?',
        'answer': 'after the moon it is the brightest object in our night sky',
        Options: [
            ' Plato',
            ' Aristotle',
            'Ptolemy',
            'Eratosthenes',
        ]

    },
    {
        'Question': 'Q3 = Which among the following region is called as rust belt of Japan?',
        'answer': 'after the moon it is the brightest object in our night sky',
        Options: [
            'Shikoku',
            ' Honsh',
            ' Kyushū',
            ' Chubu',
        ]

    },

]

const shan = function (e) {
    e.preventDefault();
    location.href = "geography.html";

}
let question_count = 0;
let points = 0;

function next() {
    if (question_count == geography.length){
        location.href = "endpage.html";

    }
  
    let abdul = document.getElementsByClassName(".offline").innerHTML;
    if (abdul === geography[question_count].answer){
        points += 10;
    }

    
    show(question_count);
    question_count++;
    sessionStorage.setItem("points",points);
  
}
function show(count) {
    document.getElementById("zeeshan").innerHTML = `<h2>${geography[count].Question} </h2>,
<ul>
<li class="option" id="option1">${geography[count].Options[0]}</li>
<li class="option" id="option2">${geography[count].Options[1]}</li>
<li class="option" id="option3">${geography[count].Options[2]}</li>
<li class="option" id="option4">${geography[count].Options[3]}</li>
</ul>`
toggleActive();
}

 const toggleActive = function (){
    let hasan = document.querySelectorAll("li.option");

    for( let i=0; i<hasan.length; i++){
        hasan[i].onclick = function(){
            for(let j=0; j<hasan.length; j++){
                if(hasan[j].classList.contains("offline")){
                    hasan[j].classList.remove("offline");
                }
            }
            hasan[i].classList.add("offline");
        }
    }
}

let IT_quiz = [
    {
        'Question': 'Q1 = A computer system is the integration of physical entities called hardware and non physical entities called',
        'answer': 'software',
        Options: [
            ' Software',
            ' Hardware',
            ' Firmware',
            ' Liveware'
        ]

    },
    {
        'Question': 'Q2 = CPU reads and executes program instructions, performs calculations and ____?',
        'answer': 'make decisions',
        Options: [
            ' make distribution',
            ' make direction',
            'make diversion',
            ' make decisions'
        ]

    },
    {
        'Question': 'Q3 = ____ card is an input device stores data in a microprocessor embedded in the card.?',
        'answer': 'smart',
        Options: [
            'Sim',
            ' Smart',
            ' Magnetic',
            'Laser',

        ]

    },

]



const noman = function (e) {
    e.preventDefault();
    location.href = "It.html";
}
let quiz_ = 0;
function next_2() {
    if (quiz_ == IT_quiz.length){
        location.href = "endpage.html";

    }

    let abdul = document.getElementsByClassName(".offline").innerHTML;
    if (abdul === IT_quiz[quiz_].answer){
        points += 10;
    }
    sessionStorage.setItem("points",points);
    display(quiz_);
    quiz_++;

}
function display(count_) {
    document.getElementById("noman").innerHTML = `<h2>${IT_quiz[count_].Question}</h2>,
    <ul>
    <li class="option" id="option1">${IT_quiz[count_].Options[0]}</li>
    <li class="option" id="option2">${IT_quiz[count_].Options[1]}</li>
    <li class="option" id="option3">${IT_quiz[count_].Options[2]}</li>
    <li class="option" id="option4">${IT_quiz[count_].Options[3]}</li>
</ul> `
toggleActive();
}

let sports_quiz = [
    {
        'Question': 'Q1 = The famous football player Maradona belongs to which among the following countries?',
        'answer': 'Argentina',
        Options: [
            'Brazil',
            'Chile',
            'Argentina',
            'Italy'
        ]

    },
    {
        'Question': 'Q2 = Velodrome is an arena for which among the following sporting events ?',
        'answer': 'Track Cycling',
        Options: [
            'Lawn tennis',
            'Ice Hockey',
            'Track Cycling',
            'Formula 1 racing'
        ]

    },
    {
        'Question': 'Q3 =  In which among the following years, the Modern Olympic games were held for the first time?',
        'answer': '1896',
        Options: [
            '1889',
            ' 1896',
            '1876',
            ' 1898',
        ]

    },

]
const sanaullah = function (e) {
    e.preventDefault();
    location.href = "Sports.html";
}
let quiz_2 = 0;
const next_3 =function () {
    if (quiz_2 == sports_quiz.length){
        location.href = "endpage.html";

    }

    let abdul = document.getElementsByClassName(".offline").innerHTML;
    if (abdul === sports_quiz[quiz_2].answer){
        points += 10;
    }
    sessionStorage.setItem("points",points);
    display_2(quiz_2);
    quiz_2++;
  
}
function display_2(count_2) {
    document.getElementById("sanaullah").innerHTML = `<h2>${sports_quiz[count_2].Question}</h2>,
    <ul>
    <li class="option" id="option1">${sports_quiz[count_2].Options[0]}</li>
    <li class="option" id="option2">${sports_quiz[count_2].Options[1]}</li>
    <li class="option" id="option3">${sports_quiz[count_2].Options[2]}</li>
    <li class="option" id="option4">${sports_quiz[count_2].Options[3]}</li>
</ul>`
toggleActive();
// location.href = "endpage.html"
}
let result_bro = document.getElementById("points");
let api_result = sessionStorage.getItem("points");
result_bro.innerHTML= api_result;
let remarks = "";
let bhai_bro = document.getElementById("remarks");
if(api_result == 0){
    remarks = "bad";
    
}else if(api_result == 10){
    remarks ="keep practisng";
}else if(api_result == 20){
    remarks = "good";
}else{
    remarks= "execelant";
}

bhai_bro.innerHTML = remarks;
