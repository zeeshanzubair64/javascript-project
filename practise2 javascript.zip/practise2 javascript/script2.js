
function pakistan(e){
    let dateofbirth = document.getElementById("dateofbirth");
    e.preventDefault();
    dateofbirth = dateofbirth.value;
    dateofbirth = new Date(dateofbirth);
    const month = dateofbirth.getMonth();
    const day = dateofbirth.getDate();

    let zodiac_sign = "";
    let zodiac_date = "";

    if((month===0  && day>=20) || (month===1  &&  day<=18)){
        zodiac_sign = "Aquarius";
        zodiac_date = "Jan 20-Feb 18"

    }else if ((month===1  && day>=19) || (month===2  &&  day<=20)){
        zodiac_sign = "Pisces";
        zodiac_date = "Feb 19-March 20 "

    }else if ((month===2  && day>=21) || (month===3  &&  day<=19)){
        zodiac_sign = "Aries";
        zodiac_date = "April 20-May 20 "

    }else if ((month===3  && day>=20) || (month===4  &&  day<=20)){
        zodiac_sign = "Gemini";
        zodiac_date = "May 21-June 20 "

    }else if ((month===4  && day>=21) || (month===5  &&  day<=20)){
        zodiac_sign = "Taurus";
        zodiac_date = "April 20-May 20  "

    }else if ((month===5  && day>=21) || (month===6  &&  day<=22)){
        zodiac_sign = "Cancer";
        zodiac_date = "June 21-July 22 "

    }else if ((month===6  && day>=23) || (month===7  &&  day<=22)){
        zodiac_sign = "Leo—";
        zodiac_date = "July 23-August 22 "

    }else if ((month===7  && day>=23) || (month===8  &&  day<=22)){
        zodiac_sign = "Virgo—";
        zodiac_date = "August 23-September 22  "

    }else if ((month===8  && day>=23) || (month===9  &&  day<=22)){
        zodiac_sign = "Libra";
        zodiac_date = "September 23-October 22 "

    }else if ((month===9  && day>=23) || (month===10  &&  day<=21)){
        zodiac_sign = "Scorpio";
        zodiac_date = "October 23-November 21 "

    }else if ((month===10  && day>=22) || (month===11  &&  day<=21)){
        zodiac_sign = "Sagittarius";
        zodiac_date = "November 22-December 21"
     
    // }else if ((month===11  && day>=22) || (month===0  &&  day<=19)){
    //     zodiac_sign = "Capricorn";
    //     zodiac_date = "December 22-January 19"
    // }
    
      }  else{
        zodiac_sign = "Capricorn";
        zodiac_date = "December 22-January 19"
    }
    
    sessionStorage.setItem("zodiac_sign", zodiac_sign );
    sessionStorage.setItem("zodiac_date", zodiac_date);
    location.href = "result.html";
}
 let element = sessionStorage.getItem("zodiac_sign");
 let element_2 = sessionStorage.getItem("zodiac_date");

let zodiacsign = document.getElementById("zodiacsign");
zodiacsign.innerHTML = `<h1>${element}</h1>
<p>${element_2}</p>`;